from sqlalchemy import Column, Integer, String,false,Boolean
from database import Base

class meeting(Base):

    __tablename__ = "meeting"
    id = Column(Integer, primary_key=True, index=True)
    user = Column(String, nullable=false)
    password = Column(String, nullable=false)
    Conference_room_name = Column(String)
    No_of_seats = Column(Integer)
    Is_Projector_or_TV_availability = Column(Boolean, default=None)
    Location = Column(String)
    Active = Column(Boolean, default=None)
